This is a directory to which DRC messages are output.
