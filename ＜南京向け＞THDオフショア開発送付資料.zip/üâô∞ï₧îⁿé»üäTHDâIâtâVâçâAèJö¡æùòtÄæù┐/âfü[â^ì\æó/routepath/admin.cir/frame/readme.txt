This is a directory to which Frame data are output.
