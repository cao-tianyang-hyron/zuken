This is a directory to which error messages are output.
