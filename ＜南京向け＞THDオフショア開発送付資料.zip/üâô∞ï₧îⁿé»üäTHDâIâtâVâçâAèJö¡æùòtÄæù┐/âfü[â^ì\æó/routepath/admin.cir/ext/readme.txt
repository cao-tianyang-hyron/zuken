This is a directory to which Netlist are output.
